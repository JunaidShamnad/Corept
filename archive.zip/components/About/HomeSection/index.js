import {
  Section,
  Container,
  Head,
  Title,
} from "./styled.elements";

function index() {
  return (
    <Section>
      <Container>

        <Head>
          <Title>About Us</Title>
        </Head>
  

      </Container>
    </Section>
  );
}

export default index;
