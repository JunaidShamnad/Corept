import {
  Section,
  Container,
  Head,
  Title,
} from "./styled.elements";

function index() {
  return (
    <Section>
      <Container>

        <Head>
          <Title>Contact Us</Title>
        </Head>
  

      </Container>
    </Section>
  );
}

export default index;
