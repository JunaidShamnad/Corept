import {
  Section,
  Container,
  Head,
  Title,
} from "./styled.elements";

function index() {
  return (
    <Section>
      <Container>

        <Head>
          <Title>Projects</Title>
        </Head>
  

      </Container>
    </Section>
  );
}

export default index;
