

import Home from '../../components/Contact/HomeSection'
import Form from '../../components/Contact/FormSection'
import Address from '../../components/Contact/AddressSection'

export default function HomePage() {
  return (
        <>
          <Home/>
          <Form/>
          <Address/>
        </>
  )



}