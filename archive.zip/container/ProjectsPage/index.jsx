import Projects from '../../components/Services/ProjectSection'

const ProjectsPage = () => {
    return (
      <Projects/>
    )
  }
  
  export default ProjectsPage