const Links = [
  { name: "Home", to: "/", id: 0 },
  { name: "About", to: "/about-us", id: 1 },
  { name: "Projects", to: "/projects", id: 2 },
  { name: "Contact", to: "/contact-us", id: 3 },
];

export default Links;
