


const Projects = [
    { alt: "first", src: "/images/projectImg/Web capture_15-7-2022_194437_.jpeg", id: 0 },
    { alt: "second", src: "/images/projectImg/Web capture_15-7-2022_194451_.jpeg", id: 1 },
    { alt: "third", src: "/images/projectImg/Web capture_15-7-2022_194515_.jpeg", id: 2 },
    { alt: "fourth", src: "/images/projectImg/Web capture_15-7-2022_194526_.jpeg", id: 3 },
    { alt: "fifth", src: "/images/projectImg/Web capture_15-7-2022_194537_.jpeg", id: 4 },
    { alt: "sixth", src: "/images/projectImg/Web capture_15-7-2022_194547_.jpeg", id: 5 },
    { alt: "seventh", src: "/images/projectImg/Web capture_15-7-2022_19454_.jpeg", id: 6 },

  ];
  
  export default Projects;
  